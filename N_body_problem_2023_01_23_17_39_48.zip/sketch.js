var k = 100;
var planetas = [] ; 
let extraCanvas;

function setup() {
  
  frameRate(60);
  createCanvas(600, 600);
  extraCanvas = createGraphics(600,600);
  extraCanvas.clear();
  
  p1 = new planeta(400,300,1,-0.1,-0.1,[255,0,0]);
  p2 = new planeta(250,100,1,0,0.5,[0,255,0]); 
  p3 = new planeta(150,250,1,0,0,[0,0,255]);
  
  planetas[0] = p1; 
  planetas[1] = p2; 
  planetas[2] = p3;
  
  print(planetas);
  
   
}

function draw() {
  
  background(0);
  
   
   tracejado(p1);
   tracejado(p2); 
   tracejado(p3);
  
   gravidade(p2,p3); 
   gravidade(p1,p3); 
   gravidade(p1,p2);
  
   p1.mover();
   p2.mover();
   p3.mover(); 
  
   p1.mostrar();
   p2.mostrar(); 
   p3.mostrar();
          
       
   image(extraCanvas,0,0);   
        
  
   
    
}

class planeta { 

    constructor(x,y,m,vx,vy,Cor) { 
    
      this.x = x;
      this.y = y;
      this.m = m; 
      this.vx = vx;
      this.vy = vy; 
      this.C = Cor;
    
    }

    mostrar() {
      
      fill(this.C[0],this.C[1],this.C[2]);
      ellipse(this.x,this.y,30,30);
      
    } 
  
    mover() {
      
      this.x = this.x + this.vx; 
      this.y = this.y + this.vy; 
    } 

   
}



function gravidade ( ob1, ob2 ) { 

    var d = dist(ob1.x,ob1.y,ob2.x,ob2.y) ;
    
    var o = atan( (ob2.y - ob1.y)/(ob2.x - ob1.x) ) ; 
  
    var f = k*ob1.m*ob2.m/(Math.pow(d,2)) ; 
  
    var a1 = f/ob1.m ; 
  
    var a2 = -f/ob2.m ; 
  
    if (ob1.x >= ob2.x ) { 
    
    o = PI + o; 
    
    }
  
    ob1.vx = ob1.vx + cos(o)*a1; 
    ob1.vy = ob1.vy + sin(o)*a1;
  
    ob2.vx = ob2.vx + cos(o)*a2; 
    ob2.vy = ob2.vy + sin(o)*a2;    
}


function linha ( obj ) { 
    
    stroke(250);
    line(obj.x,0,obj.x,600); 

}


function tracejado( obj ) { 

   extraCanvas.fill(250);
   extraCanvas.stroke(250);
   extraCanvas.point(obj.x,obj.y); 

}

